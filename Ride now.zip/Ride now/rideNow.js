const arrOfBikes = [
  {
    name: "Bajaj CT 100",
    free: "110",
    excess: "2",
    price: 79,
    imgLink:
      "https://d3bvfezcznypk7.cloudfront.net/BikeImages/JPG/BajajCT100@2x.jpg",
  },
  {
    name: "Honda Activa",
    free: 80,
    excess: 2,
    price: 89,
    imgLink:
      "https://d3bvfezcznypk7.cloudfront.net/BikeImages/JPG/HondaActiva4G@2x.jpg",
  },
  {
    name: "Honda Dio",
    free: 67,
    excess: 2,
    price: 89,
    imgLink:
      "https://d3bvfezcznypk7.cloudfront.net/BikeImages/JPG/BajajCT100@2x.jpg",
  },
  {
    name: "Bajaj Pulsar 150",
    free: 71,
    excess: 2,
    price: 139,
    imgLink:
      "https://d3bvfezcznypk7.cloudfront.net/BikeImages/JPG/BajajCT100@2x.jpg",
  },
  {
    name: "Bajaj Avenger 220 Street",
    free: 293,
    excess: 2.5,
    price: 549,
    imgLink:
      "https://d3bvfezcznypk7.cloudfront.net/BikeImages/JPG/BajajAvengerStreet220@2x.jpg",
  },
  {
    name: "Bajaj Pulsar 150",
    free: 71,
    excess: 2,
    price: 139,
    imgLink:
      "https://d3bvfezcznypk7.cloudfront.net/BikeImages/JPG/BajajCT100@2x.jpg",
  },
  {
    name: "Bajaj Pulsar 150",
    free: 71,
    excess: 2,
    price: 139,
    imgLink:
      "https://d3bvfezcznypk7.cloudfront.net/BikeImages/JPG/BajajCT100@2x.jpg",
  },
];
